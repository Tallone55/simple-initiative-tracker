"""Modal dialogs, built from their .ui files. These are plain functions
rather than methods on AppWindow -- each takes the parent window and a
callback to invoke on success, so they don't need to know anything about
AppWindow's internals.
"""

import random

from gi.repository import Gtk

from constants import EDIT_FIELD_UI_PATH, EDIT_HITPOINTS_UI_PATH, ADD_CREATURE_UI_PATH
from models import Creature


def open_edit_dialog(parent, creature_obj, field_name, display_name, on_committed):
    """on_committed(resort: bool) is called after a successful update,
    once the dialog has already been destroyed."""
    builder = Gtk.Builder()
    builder.add_from_file(EDIT_FIELD_UI_PATH)

    window = builder.get_object("edit_window")
    entry = builder.get_object("edit_entry")
    update_button = builder.get_object("update_button")
    cancel_button = builder.get_object("cancel_button")

    window.set_title(f"Edit {display_name}")
    window.set_transient_for(parent)

    current_value = getattr(creature_obj, field_name)
    entry.set_text(str(current_value))

    def on_update(_button):
        raw = entry.get_text().strip()
        entry.remove_css_class("error")

        if field_name == "name":
            setattr(creature_obj, field_name, raw or "Unnamed")
        else:
            try:
                setattr(creature_obj, field_name, int(raw))
            except ValueError:
                entry.add_css_class("error")
                return

        resort = field_name == "initiative_roll"
        window.destroy()
        on_committed(resort=resort)

    def on_cancel(_button):
        window.destroy()

    update_button.connect("clicked", on_update)
    cancel_button.connect("clicked", on_cancel)
    window.present()


def open_edit_hitpoints_dialog(parent, creature_obj, on_committed):
    """Dedicated hitpoints editor: two spin buttons (current / max) rather
    than a plain text field, since HP changes are usually small relative
    adjustments (damage/healing) rather than typed-out new values. Spin
    buttons give native +/- increment buttons as well as direct typing.
    """
    builder = Gtk.Builder()
    builder.add_from_file(EDIT_HITPOINTS_UI_PATH)

    window = builder.get_object("edit_hitpoints_window")
    current_spin = builder.get_object("current_hp_spin")
    max_spin = builder.get_object("max_hp_spin")
    update_button = builder.get_object("update_button")
    cancel_button = builder.get_object("cancel_button")

    window.set_transient_for(parent)

    max_spin.set_value(creature_obj.max_hitpoints)
    # Current HP is allowed to momentarily exceed max here so an existing
    # over-max value (e.g. from a hand-edited CSV) doesn't get silently
    # clamped just from opening the dialog.
    current_spin.set_range(0, max(creature_obj.max_hitpoints, creature_obj.hitpoints))
    current_spin.set_value(creature_obj.hitpoints)

    def on_max_changed(spin):
        new_max = int(spin.get_value())
        current_spin.set_range(0, new_max)
        if current_spin.get_value() > new_max:
            current_spin.set_value(new_max)

    max_spin.connect("value-changed", on_max_changed)

    def on_update(_button):
        new_max = int(max_spin.get_value())
        new_current = int(current_spin.get_value())
        creature_obj.max_hitpoints = new_max
        creature_obj.hitpoints = min(new_current, new_max)
        window.destroy()
        on_committed(resort=False)

    def on_cancel(_button):
        window.destroy()

    update_button.connect("clicked", on_update)
    cancel_button.connect("clicked", on_cancel)
    window.present()


def open_add_creature_dialog(parent, on_added):
    """on_added(creatures: list[Creature]) is called after a successful
    add, once the dialog has already been destroyed. A list is used even
    for the common single-creature case so callers have one code path.
    """
    builder = Gtk.Builder()
    builder.add_from_file(ADD_CREATURE_UI_PATH)

    window = builder.get_object("add_window")
    name_entry = builder.get_object("name_entry")
    hp_entry = builder.get_object("hp_entry")
    ac_entry = builder.get_object("ac_entry")
    init_entry = builder.get_object("init_entry")
    count_spin = builder.get_object("count_spin")
    error_label = builder.get_object("error_label")
    add_button = builder.get_object("add_button")
    cancel_button = builder.get_object("cancel_button")

    window.set_transient_for(parent)

    def show_error(message):
        error_label.set_text(message)
        error_label.set_visible(True)

    def on_add(_button):
        try:
            hitpoints = int(hp_entry.get_text())
            armor_class = int(ac_entry.get_text())
        except ValueError:
            show_error("Hitpoints and Armor Class must be whole numbers.")
            return

        raw_init = init_entry.get_text().strip()
        if raw_init:
            try:
                fixed_initiative = int(raw_init)
            except ValueError:
                show_error(
                    "Initiative Roll must be a whole number, "
                    "or left blank to roll randomly (1-20)."
                )
                return
        else:
            fixed_initiative = None  # roll per-creature below

        base_name = name_entry.get_text().strip() or "Unnamed"
        count = int(count_spin.get_value())

        creatures = []
        for i in range(count):
            # Only number duplicates when there's more than one -- a
            # single add keeps the name exactly as typed.
            display_name = f"{base_name} {i + 1}" if count > 1 else base_name
            initiative_roll = (
                fixed_initiative if fixed_initiative is not None
                else random.randint(1, 20)
            )
            creatures.append(Creature(
                name=display_name,
                hitpoints=hitpoints,
                max_hitpoints=hitpoints,
                armor_class=armor_class,
                initiative_roll=initiative_roll,
            ))

        window.destroy()
        on_added(creatures)

    def on_cancel(_button):
        window.destroy()

    add_button.connect("clicked", on_add)
    cancel_button.connect("clicked", on_cancel)
    window.present()
